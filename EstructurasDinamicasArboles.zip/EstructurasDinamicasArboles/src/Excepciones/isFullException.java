
//MDGC

package Excepciones;


public class isFullException extends Exception{
    
    public isFullException (String msg){
        super (msg);
    }
}
