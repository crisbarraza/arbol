
//MDGC

package Excepciones;


public class isEmptyException extends Exception {
    
    public isEmptyException (String msg){
        super (msg);
    }
    
}
