
//MDGC

package stack;

import Excepciones.isEmptyException;
import Excepciones.isFullException;


public interface Stack<T>{
    
    public long size();                                         //saber cuantos valores hay
    public void isempty()       throws isEmptyException;        //saber si esta vacia
    public void isfull()        throws isFullException;         //saber si esta llena
    public void push(T value)   throws isFullException;         //
    public T    pop()           throws isEmptyException;
    public T    peek()          throws isEmptyException;
    
}
